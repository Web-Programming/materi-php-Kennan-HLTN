<div>
    <h1>Ini halaman beranda</h1>
    <h2>Hallo {{ $name }}</h2>
    <h2>Your Email is {{ $email }}</h2>
    <h2>Your Address is on {{ $address }}</h2>
</div>


