<div>
    <h1>Berita</h1>
    <h2>ID : {{ $id }}</h2>
    <h2>Judul : {{ $judul }}</h2>
</div>
