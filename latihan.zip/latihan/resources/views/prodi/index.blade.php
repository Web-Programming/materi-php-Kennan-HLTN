@extends('layout.master')

@section('title', 'Halaman List Prodi')

@section('content')
<div>
    <h1>Ini halaman prodi</h1>
</div>
@endsection